# Vibe - Music Player

A simple, Spotify-inspired music player that runs in your browser and installs as an app on any device. Upload your own music, search the web for audio, and play everything offline.

## Install as an App (PWA)

No app store needed. Install directly from your browser:

### iPhone / iPad (Safari)
1. Open the link in **Safari**
2. Tap the **Share** button (square with arrow pointing up, bottom center)
3. Scroll down and tap **"Add to Home Screen"**
4. Tap **Add**
5. Vibe appears on your home screen like a native app

### Android (Chrome)
1. Open the link in **Chrome**
2. Tap the **three dots** menu (top right)
3. Tap **"Install App"** or **"Add to Home Screen"**
4. Tap **Install**
5. Vibe appears in your app drawer

### Desktop (Chrome / Edge)
1. Open the link in Chrome or Edge
2. Click the **install icon** in the address bar (or click "Install App" in the header)
3. Click **Install**
4. Vibe opens in its own window, no browser bar

## How to Use

### Upload Music
- Click the green **Upload** button
- Drag and drop audio files or click to browse
- Supported formats: **MP3, WAV, OGG, FLAC, AAC, M4A, WebM**
- Optionally add a title and artist name
- Uploaded files are saved and playable offline immediately

### Search the Web
- Type any song name, artist, or album in the search bar
- Press **Enter** to search
- Results are ranked by quality:
  - **Audio File** (green badge) — direct download link, one-click grab
  - **Extracted** (purple badge) — audio pulled from a web page
  - **Page** (gray badge) — a web page we found, may contain audio
- Click the download button on any result to save it to your library

### Play Music
- Click any track in your library to start playing
- Use the bottom player bar:
  - **Play / Pause** — toggle playback
  - **Skip Back / Forward** — navigate between tracks
  - **Seek slider** — jump to any point in the song
  - **Volume** — adjust loudness (click speaker icon to mute)
- Tracks auto-advance to the next song when finished

### Manage Your Library
- All tracks appear in the **My Library** tab
- Tracks show their source: **Local** (uploaded) or **Web** (downloaded)
- Hover over a track and click the trash icon to delete it

## Tech Stack

- **Next.js 16** with App Router
- **TypeScript** for type safety
- **Tailwind CSS 4** for styling
- **shadcn/ui** component library
- **Zustand** for state management
- **Prisma + SQLite** for track database
- **z-ai-web-dev-sdk** for web search and page scraping

## Project Structure

```
├── public/
│   ├── manifest.json      # PWA manifest
│   ├── sw.js              # Service worker for offline caching
│   ├── icon-192.png       # App icon (small)
│   └── icon-512.png       # App icon (large)
├── prisma/
│   └── schema.prisma      # Database schema (Track model)
├── src/
│   ├── app/
│   │   ├── layout.tsx     # Root layout with PWA meta tags
│   │   ├── page.tsx       # Main music player UI
│   │   └── api/
│   │       ├── tracks/    # Track CRUD + upload endpoint
│   │       ├── search/    # Web search with audio extraction
│   │       ├── fetch/     # Download audio from URLs
│   │       └── play/      # Audio streaming endpoint
│   ├── store/
│   │   └── player-store.ts # Zustand state management
│   └── components/ui/     # shadcn/ui components
└── uploads/               # Local audio file storage
```

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/tracks` | GET | List all tracks in library |
| `/api/tracks` | POST | Upload an audio file (multipart form) |
| `/api/tracks/[id]` | DELETE | Delete a track |
| `/api/search` | POST | Search web for music (returns ranked results with extracted audio URLs) |
| `/api/fetch` | POST | Download audio from a URL and save to library |
| `/api/play/[id]` | GET | Stream a track's audio file |
