import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { writeFile, mkdir } from 'fs/promises';
import { existsSync } from 'fs';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';

export async function POST(request: NextRequest) {
  try {
    const { url, title, artist, type } = await request.json();

    if (!url) {
      return NextResponse.json({ error: 'URL required' }, { status: 400 });
    }

    let audioUrl = url;
    let resolvedTitle = title || 'Unknown Track';
    let resolvedArtist = artist || null;

    // If the URL is a web page (not direct audio), scrape it for audio
    if (type !== 'direct' && !/\.(mp3|wav|ogg|flac|aac|m4a|webm)(\?|$)/i.test(url)) {
      try {
        const ZAI = (await import('z-ai-web-dev-sdk')).default;
        const zai = await ZAI.create();

        const pageData = await zai.functions.invoke('page_reader', { url });
        const html = pageData.data?.html || '';
        const pageTitle = pageData.data?.title || '';

        if (pageTitle) {
          resolvedTitle = extractTitle(pageTitle);
          const a = extractArtist(pageTitle);
          if (a) resolvedArtist = a;
        }

        // Extract audio URLs from page
        const audioUrls = extractAudioUrls(html, url);
        if (audioUrls.length > 0) {
          audioUrl = audioUrls[0];
        } else {
          return NextResponse.json(
            { error: 'No audio file found on this page. Try uploading the file directly.' },
            { status: 404 }
          );
        }
      } catch (err) {
        console.error('Page scrape error:', err);
        // Try direct fetch as fallback
      }
    }

    // Fetch the audio
    const response = await fetch(audioUrl, {
      redirect: 'follow',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      },
    });

    if (!response.ok) {
      return NextResponse.json(
        { error: `Failed to fetch audio: ${response.status}` },
        { status: response.status }
      );
    }

    const contentType = response.headers.get('content-type') || '';
    const isAudio = contentType.startsWith('audio/') || contentType === 'application/octet-stream';

    if (!isAudio) {
      return NextResponse.json(
        { error: 'URL does not point to an audio file' },
        { status: 400 }
      );
    }

    // Determine file extension
    const extMap: Record<string, string> = {
      'audio/mpeg': 'mp3',
      'audio/wav': 'wav',
      'audio/ogg': 'ogg',
      'audio/flac': 'flac',
      'audio/aac': 'aac',
      'audio/mp4': 'm4a',
      'audio/webm': 'webm',
    };
    const ext = extMap[contentType] || 'mp3';

    // Save file
    const uploadsDir = path.join(process.cwd(), 'uploads');
    if (!existsSync(uploadsDir)) {
      await mkdir(uploadsDir, { recursive: true });
    }

    const fileName = `${uuidv4()}.${ext}`;
    const filePath = path.join(uploadsDir, fileName);

    const arrayBuffer = await response.arrayBuffer();
    await writeFile(filePath, Buffer.from(arrayBuffer));

    // Save to database
    const track = await db.track.create({
      data: {
        title: resolvedTitle,
        artist: resolvedArtist,
        fileType: ext,
        source: 'web',
        fileName: fileName,
        fileSize: arrayBuffer.byteLength,
      },
    });

    return NextResponse.json(track, { status: 201 });
  } catch (error) {
    console.error('Download error:', error);
    return NextResponse.json({ error: 'Failed to download track' }, { status: 500 });
  }
}

function extractAudioUrls(html: string, baseUrl: string): string[] {
  const urls: { url: string; priority: number }[] = [];

  const audioSrcMatches = html.matchAll(/<audio[^>]*\bsrc=["']([^"']+)["']/gi);
  for (const match of audioSrcMatches) {
    urls.push({ url: resolveUrl(match[1], baseUrl), priority: 10 });
  }

  const sourceMatches = html.matchAll(/<source[^>]*\bsrc=["']([^"']+)["'][^>]*\btype=["']audio\/[^"']+["']/gi);
  for (const match of sourceMatches) {
    urls.push({ url: resolveUrl(match[1], baseUrl), priority: 15 });
  }

  const ogAudioMatches = html.matchAll(/<meta[^>]*\bproperty=["']og:audio["'][^>]*\bcontent=["']([^"']+)["']/gi);
  for (const match of ogAudioMatches) {
    urls.push({ url: resolveUrl(match[1], baseUrl), priority: 20 });
  }

  const linkMatches = html.matchAll(/<a[^>]*\bhref=["']([^"']*\.(mp3|wav|ogg|flac|aac|m4a|webm)(\?[^"']*)?)["']/gi);
  for (const match of linkMatches) {
    urls.push({ url: resolveUrl(match[1], baseUrl), priority: 25 });
  }

  const dataMatches = html.matchAll(/["']([^"']*\.(mp3|wav|ogg|flac|aac|m4a|webm)(\?[^"']*)?)["']/gi);
  for (const match of dataMatches) {
    if (!urls.some((u) => u.url === resolveUrl(match[1], baseUrl))) {
      urls.push({ url: resolveUrl(match[1], baseUrl), priority: 5 });
    }
  }

  const seen = new Set<string>();
  const unique = urls.filter((u) => {
    if (seen.has(u.url)) return false;
    seen.add(u.url);
    return true;
  });
  unique.sort((a, b) => b.priority - a.priority);

  return unique.map((u) => u.url);
}

function resolveUrl(url: string, base: string): string {
  try {
    if (url.startsWith('http://') || url.startsWith('https://')) return url;
    return new URL(url, base).href;
  } catch {
    return url;
  }
}

function extractTitle(name: string): string {
  let title = name;
  title = title.replace(/\s*[-|–].*$/, '').trim();
  title = title.replace(/\s*\(.*\)\s*$/, '').trim();
  if (title.length < 3) {
    title = name.split(' - ')[0]?.trim() || name;
  }
  return title || name;
}

function extractArtist(name: string): string | undefined {
  const parts = name.split(' - ');
  if (parts.length >= 2) return parts[0].trim();
  return undefined;
}
