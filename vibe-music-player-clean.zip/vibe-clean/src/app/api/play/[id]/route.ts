import { NextRequest, NextResponse } from 'next/server';
import { readFile, stat } from 'fs/promises';
import path from 'path';
import { db } from '@/lib/db';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const track = await db.track.findUnique({ where: { id } });
    if (!track) {
      return NextResponse.json({ error: 'Track not found' }, { status: 404 });
    }

    const filePath = path.join(process.cwd(), 'uploads', track.fileName);
    const fileBuffer = await readFile(filePath);
    const fileStat = await stat(filePath);

    const contentType = getContentType(track.fileType);

    return new NextResponse(fileBuffer, {
      headers: {
        'Content-Type': contentType,
        'Content-Length': fileStat.size.toString(),
        'Accept-Ranges': 'bytes',
        'Cache-Control': 'public, max-age=3600',
      },
    });
  } catch (error) {
    console.error('Play error:', error);
    return NextResponse.json({ error: 'Failed to play track' }, { status: 500 });
  }
}

function getContentType(fileType: string): string {
  const types: Record<string, string> = {
    mp3: 'audio/mpeg',
    wav: 'audio/wav',
    ogg: 'audio/ogg',
    flac: 'audio/flac',
    aac: 'audio/aac',
    m4a: 'audio/mp4',
    wma: 'audio/x-ms-wma',
    webm: 'audio/webm',
  };
  return types[fileType.toLowerCase()] || 'audio/mpeg';
}
