import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const { query } = await request.json();

    if (!query || query.trim().length === 0) {
      return NextResponse.json({ error: 'Search query required' }, { status: 400 });
    }

    const ZAI = (await import('z-ai-web-dev-sdk')).default;
    const zai = await ZAI.create();

    // Search the web for music with multiple queries for better results
    const [search1, search2, search3] = await Promise.all([
      zai.functions.invoke('web_search', {
        query: `${query} mp3 download`,
        num: 8,
      }),
      zai.functions.invoke('web_search', {
        query: `${query} free audio file`,
        num: 5,
      }),
      zai.functions.invoke('web_search', {
        query: `${query} song download free`,
        num: 5,
      }),
    ]);

    // Combine and deduplicate
    const allResults = [...search1, ...search2, ...search3];
    const seen = new Set<string>();
    const uniqueResults = allResults.filter((r) => {
      if (seen.has(r.url)) return false;
      seen.add(r.url);
      return true;
    });

    // Score results: prefer direct audio file links and known free music sites
    const scored = uniqueResults.map((r) => {
      let score = 0;
      const urlLower = r.url.toLowerCase();
      const nameLower = r.name.toLowerCase();

      // Direct audio file links score highest
      if (/\.(mp3|wav|ogg|flac|aac|m4a|webm)(\?|$)/i.test(urlLower)) score += 100;

      // Known free music / file hosting patterns
      if (/archive\.org|freesound|soundcloud|bandcamp|mixcloud|reverbnation/i.test(urlLower)) score += 30;
      if (/download|free|mp3|audio/i.test(urlLower)) score += 15;
      if (/download|free|mp3|audio/i.test(nameLower)) score += 10;

      return { ...r, score };
    });

    // Sort by score descending
    scored.sort((a, b) => b.score - a.score);

    // Scrape top results to find actual audio URLs (up to 5 pages)
    const audioResults: AudioSearchResult[] = [];
    const scrapeLimit = Math.min(5, scored.length);

    for (let i = 0; i < scrapeLimit; i++) {
      const result = scored[i];
      try {
        // Check if it's already a direct audio link
        if (/\.(mp3|wav|ogg|flac|aac|m4a|webm)(\?|$)/i.test(result.url)) {
          audioResults.push({
            title: extractTitle(result.name),
            artist: extractArtist(result.name, result.snippet),
            audioUrl: result.url,
            pageUrl: result.url,
            source: result.host_name,
            snippet: result.snippet,
            type: 'direct',
          });
          continue;
        }

        // Scrape the page for audio URLs
        const pageData = await zai.functions.invoke('page_reader', { url: result.url });
        const html = pageData.data?.html || '';
        const pageTitle = pageData.data?.title || result.name;

        // Extract audio URLs from the page
        const audioUrls = extractAudioUrls(html, result.url);

        if (audioUrls.length > 0) {
          // Pick the best audio URL
          const bestAudio = audioUrls[0];
          audioResults.push({
            title: extractTitle(pageTitle || result.name),
            artist: extractArtist(result.name, result.snippet),
            audioUrl: bestAudio,
            pageUrl: result.url,
            source: result.host_name,
            snippet: result.snippet,
            type: 'scraped',
          });
        } else {
          // No audio found on page, still show as a regular result
          audioResults.push({
            title: extractTitle(result.name),
            artist: extractArtist(result.name, result.snippet),
            audioUrl: result.url,
            pageUrl: result.url,
            source: result.host_name,
            snippet: result.snippet,
            type: 'page',
          });
        }
      } catch {
        // Page scrape failed, still include as a regular link
        audioResults.push({
          title: extractTitle(result.name),
          artist: extractArtist(result.name, result.snippet),
          audioUrl: result.url,
          pageUrl: result.url,
          source: result.host_name,
          snippet: result.snippet,
          type: 'page',
        });
      }
    }

    // Add remaining non-scraped results
    for (let i = scrapeLimit; i < scored.length; i++) {
      const result = scored[i];
      audioResults.push({
        title: extractTitle(result.name),
        artist: extractArtist(result.name, result.snippet),
        audioUrl: result.url,
        pageUrl: result.url,
        source: result.host_name,
        snippet: result.snippet,
        type: 'page',
      });
    }

    return NextResponse.json(audioResults);
  } catch (error) {
    console.error('Search error:', error);
    return NextResponse.json({ error: 'Search failed' }, { status: 500 });
  }
}

interface AudioSearchResult {
  title: string;
  artist?: string;
  audioUrl: string;
  pageUrl: string;
  source: string;
  snippet: string;
  type: 'direct' | 'scraped' | 'page';
}

/**
 * Extract audio file URLs from HTML content
 */
function extractAudioUrls(html: string, baseUrl: string): string[] {
  const urls: { url: string; priority: number }[] = [];

  // Pattern 1: <audio src="...">
  const audioSrcMatches = html.matchAll(/<audio[^>]*\bsrc=["']([^"']+)["']/gi);
  for (const match of audioSrcMatches) {
    urls.push({ url: resolveUrl(match[1], baseUrl), priority: 10 });
  }

  // Pattern 2: <source src="..."> inside <audio>
  const sourceMatches = html.matchAll(/<source[^>]*\bsrc=["']([^"']+)["'][^>]*\btype=["']audio\/[^"']+["']/gi);
  for (const match of sourceMatches) {
    urls.push({ url: resolveUrl(match[1], baseUrl), priority: 15 });
  }

  // Pattern 3: og:audio meta tags
  const ogAudioMatches = html.matchAll(/<meta[^>]*\bproperty=["']og:audio["'][^>]*\bcontent=["']([^"']+)["']/gi);
  for (const match of ogAudioMatches) {
    urls.push({ url: resolveUrl(match[1], baseUrl), priority: 20 });
  }
  const ogAudioUrlMatches = html.matchAll(/<meta[^>]*\bcontent=["']([^"']+\.mp3[^"']*)["'][^>]*\bproperty=["']og:audio["']/gi);
  for (const match of ogAudioUrlMatches) {
    urls.push({ url: resolveUrl(match[1], baseUrl), priority: 20 });
  }

  // Pattern 4: Direct links to audio files in <a href="...">
  const linkMatches = html.matchAll(/<a[^>]*\bhref=["']([^"']*\.(mp3|wav|ogg|flac|aac|m4a|webm)(\?[^"']*)?)["']/gi);
  for (const match of linkMatches) {
    urls.push({ url: resolveUrl(match[1], baseUrl), priority: 25 });
  }

  // Pattern 5: JSON-LD or data attributes with audio URLs
  const dataMatches = html.matchAll(/["']([^"']*\.(mp3|wav|ogg|flac|aac|m4a|webm)(\?[^"']*)?)["']/gi);
  for (const match of dataMatches) {
    if (!urls.some((u) => u.url === resolveUrl(match[1], baseUrl))) {
      urls.push({ url: resolveUrl(match[1], baseUrl), priority: 5 });
    }
  }

  // Deduplicate and sort by priority
  const seen = new Set<string>();
  const unique = urls.filter((u) => {
    if (seen.has(u.url)) return false;
    seen.add(u.url);
    return true;
  });
  unique.sort((a, b) => b.priority - a.priority);

  return unique.map((u) => u.url);
}

/**
 * Resolve a potentially relative URL against a base URL
 */
function resolveUrl(url: string, base: string): string {
  try {
    // If already absolute, return as-is
    if (url.startsWith('http://') || url.startsWith('https://')) return url;
    // Resolve relative
    return new URL(url, base).href;
  } catch {
    return url;
  }
}

function extractTitle(name: string): string {
  let title = name;
  title = title.replace(/\s*[-|–].*$/, '').trim();
  title = title.replace(/\s*\(.*\)\s*$/, '').trim();
  if (title.length < 3) {
    title = name.split(' - ')[0]?.trim() || name;
  }
  return title || name;
}

function extractArtist(name: string, snippet: string): string | undefined {
  const parts = name.split(' - ');
  if (parts.length >= 2) {
    return parts[0].trim();
  }
  const match = snippet.match(/by\s+([^,.\n]+)/i);
  if (match) return match[1].trim();
  return undefined;
}
