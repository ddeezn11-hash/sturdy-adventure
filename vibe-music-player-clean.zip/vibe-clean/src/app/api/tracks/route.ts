import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { writeFile, mkdir } from 'fs/promises';
import { existsSync } from 'fs';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';

export async function GET() {
  try {
    const tracks = await db.track.findMany({
      orderBy: { createdAt: 'desc' },
    });
    return NextResponse.json(tracks);
  } catch {
    return NextResponse.json({ error: 'Failed to fetch tracks' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get('file') as File | null;
    const title = formData.get('title') as string | null;
    const artist = formData.get('artist') as string | null;
    const album = formData.get('album') as string | null;

    if (!file) {
      return NextResponse.json({ error: 'No file provided' }, { status: 400 });
    }

    // Ensure uploads directory exists
    const uploadsDir = path.join(process.cwd(), 'uploads');
    if (!existsSync(uploadsDir)) {
      await mkdir(uploadsDir, { recursive: true });
    }

    // Generate unique filename
    const ext = file.name.split('.').pop() || 'mp3';
    const fileName = `${uuidv4()}.${ext}`;
    const filePath = path.join(uploadsDir, fileName);

    // Write file
    const bytes = await file.arrayBuffer();
    await writeFile(filePath, Buffer.from(bytes));

    // Save to database
    const track = await db.track.create({
      data: {
        title: title || file.name.replace(/\.[^.]+$/, ''),
        artist: artist || null,
        album: album || null,
        fileType: ext,
        source: 'upload',
        fileName: fileName,
        fileSize: file.size,
      },
    });

    return NextResponse.json(track, { status: 201 });
  } catch (error) {
    console.error('Upload error:', error);
    return NextResponse.json({ error: 'Failed to upload track' }, { status: 500 });
  }
}
