'use client';

declare global {
  interface BeforeInstallPromptEvent extends Event {
    prompt(): Promise<void>;
    userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
  }
}

import { useCallback, useEffect, useRef, useState } from 'react';
import { usePlayerStore, type Track, type SearchResult } from '@/store/player-store';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Search,
  Upload,
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
  Music2,
  Trash2,
  Download,
  X,
  ListMusic,
  Cloud,
  HardDrive,
  Loader2,
  Plus,
  Smartphone,
} from 'lucide-react';
import { toast } from 'sonner';

function formatTime(seconds: number): string {
  if (isNaN(seconds) || seconds < 0) return '0:00';
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

function formatFileSize(bytes: number): string {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / 1048576).toFixed(1) + ' MB';
}

// ==================== UPLOAD DIALOG ====================
function UploadDialog({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const [dragActive, setDragActive] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [title, setTitle] = useState('');
  const [artist, setArtist] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const selectedFile = useRef<File | null>(null);

  const handleUpload = async () => {
    const file = selectedFile.current;
    if (!file) return;

    setUploading(true);
    try {
      const formData = new FormData();
      formData.append('file', file);
      if (title) formData.append('title', title);
      if (artist) formData.append('artist', artist);

      const res = await fetch('/api/tracks', {
        method: 'POST',
        body: formData,
      });

      if (!res.ok) throw new Error('Upload failed');

      const track = await res.json();
      usePlayerStore.getState().addTrack(track as Track);
      toast.success(`"${track.title}" added to your library`);
      onClose();
      setTitle('');
      setArtist('');
      selectedFile.current = null;
    } catch {
      toast.error('Failed to upload file');
    } finally {
      setUploading(false);
    }
  };

  const handleFileSelect = (files: FileList | null) => {
    if (files && files[0]) {
      selectedFile.current = files[0];
      if (!title) setTitle(files[0].name.replace(/\.[^.]+$/, ''));
    }
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm">
      <div className="w-full max-w-md rounded-2xl bg-[#181818] p-6 mx-4 shadow-2xl border border-white/10">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold">Upload Music</h2>
          <Button variant="ghost" size="icon" onClick={onClose} className="text-zinc-400 hover:text-white">
            <X className="h-5 w-5" />
          </Button>
        </div>

        <div
          className={`relative border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all ${
            dragActive
              ? 'border-green-500 bg-green-500/10'
              : 'border-zinc-600 hover:border-zinc-400 bg-zinc-900/50'
          }`}
          onDragOver={(e) => { e.preventDefault(); setDragActive(true); }}
          onDragLeave={() => setDragActive(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragActive(false);
            handleFileSelect(e.dataTransfer.files);
          }}
          onClick={() => fileInputRef.current?.click()}
        >
          <Upload className="h-10 w-10 mx-auto mb-3 text-zinc-400" />
          <p className="text-zinc-300 text-sm">
            Drop audio files here or click to browse
          </p>
          <p className="text-zinc-500 text-xs mt-1">
            MP3, WAV, OGG, FLAC, AAC, M4A
          </p>
          {selectedFile.current && (
            <p className="text-green-400 text-sm mt-3 font-medium">
              {selectedFile.current.name} ({formatFileSize(selectedFile.current.size)})
            </p>
          )}
          <input
            ref={fileInputRef}
            type="file"
            accept="audio/*"
            className="hidden"
            onChange={(e) => handleFileSelect(e.target.files)}
          />
        </div>

        <div className="mt-4 space-y-3">
          <Input
            placeholder="Title (optional)"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="bg-zinc-800 border-zinc-700 text-white placeholder:text-zinc-500"
          />
          <Input
            placeholder="Artist (optional)"
            value={artist}
            onChange={(e) => setArtist(e.target.value)}
            className="bg-zinc-800 border-zinc-700 text-white placeholder:text-zinc-500"
          />
        </div>

        <Button
          className="w-full mt-5 bg-green-600 hover:bg-green-700 text-white font-semibold"
          onClick={handleUpload}
          disabled={uploading || !selectedFile.current}
        >
          {uploading ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Uploading...
            </>
          ) : (
            <>
              <Upload className="h-4 w-4 mr-2" />
              Upload
            </>
          )}
        </Button>
      </div>
    </div>
  );
}

// ==================== SEARCH RESULT CARD ====================
function SearchResultCard({ result }: { result: SearchResult }) {
  const [downloading, setDownloading] = useState(false);

  const handleDownload = async () => {
    setDownloading(true);
    try {
      const res = await fetch('/api/fetch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          url: result.audioUrl || result.url,
          title: result.title,
          artist: result.artist,
          type: result.type,
        }),
      });

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || 'Download failed');
      }

      const track = await res.json();
      usePlayerStore.getState().addTrack(track as Track);
      toast.success(`"${track.title}" downloaded and added`);
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Failed to download';
      toast.error(message);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="flex items-center gap-3 p-3 rounded-lg bg-zinc-800/50 hover:bg-zinc-700/50 transition-colors group">
      <div className="flex-shrink-0 w-10 h-10 rounded-md bg-zinc-700 flex items-center justify-center">
        {result.type === 'direct' ? (
          <Download className="h-5 w-5 text-green-400" />
        ) : result.type === 'scraped' ? (
          <Cloud className="h-5 w-5 text-purple-400" />
        ) : (
          <Search className="h-5 w-5 text-zinc-400" />
        )}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-zinc-200 truncate">{result.title}</p>
        <div className="flex items-center gap-2">
          <p className="text-xs text-zinc-500 truncate">
            {result.artist && <span>{result.artist} &middot; </span>}
            {result.source}
          </p>
          <span className={`text-xs px-1.5 py-0.5 rounded flex-shrink-0 ${
            result.type === 'direct'
              ? 'bg-green-500/10 text-green-400'
              : result.type === 'scraped'
                ? 'bg-purple-500/10 text-purple-400'
                : 'bg-zinc-700 text-zinc-400'
          }`}>
            {result.type === 'direct' ? 'Audio File' : result.type === 'scraped' ? 'Extracted' : 'Page'}
          </span>
        </div>
      </div>
      <Button
        size="sm"
        variant="ghost"
        className="text-green-400 hover:text-green-300 hover:bg-green-500/10 flex-shrink-0"
        onClick={handleDownload}
        disabled={downloading}
      >
        {downloading ? (
          <Loader2 className="h-4 w-4 animate-spin" />
        ) : (
          <Download className="h-4 w-4" />
        )}
      </Button>
    </div>
  );
}

// ==================== TRACK ROW ====================
function TrackRow({
  track,
  isActive,
  onPlay,
  onDelete,
}: {
  track: Track;
  isActive: boolean;
  onPlay: () => void;
  onDelete: () => void;
}) {
  return (
    <div
      className={`flex items-center gap-3 px-3 py-2.5 rounded-lg cursor-pointer transition-all group ${
        isActive
          ? 'bg-green-600/20 border border-green-500/30'
          : 'hover:bg-zinc-800/60 border border-transparent'
      }`}
      onClick={onPlay}
    >
      <div className={`flex-shrink-0 w-10 h-10 rounded-md flex items-center justify-center ${
        isActive ? 'bg-green-600/30' : 'bg-zinc-800'
      }`}>
        {isActive && usePlayerStore.getState().isPlaying ? (
          <div className="flex items-end gap-[3px] h-4">
            <span className="w-[3px] bg-green-400 rounded-full animate-[bounce_0.6s_infinite_0ms] h-3" />
            <span className="w-[3px] bg-green-400 rounded-full animate-[bounce_0.6s_infinite_150ms] h-4" />
            <span className="w-[3px] bg-green-400 rounded-full animate-[bounce_0.6s_infinite_300ms] h-2" />
          </div>
        ) : (
          <Music2 className={`h-5 w-5 ${isActive ? 'text-green-400' : 'text-zinc-500'}`} />
        )}
      </div>

      <div className="flex-1 min-w-0">
        <p className={`text-sm font-medium truncate ${isActive ? 'text-green-400' : 'text-zinc-200'}`}>
          {track.title}
        </p>
        <div className="flex items-center gap-2">
          {track.artist && (
            <span className="text-xs text-zinc-500 truncate">{track.artist}</span>
          )}
          <span className={`text-xs px-1.5 py-0.5 rounded ${
            track.source === 'upload'
              ? 'bg-blue-500/10 text-blue-400'
              : 'bg-purple-500/10 text-purple-400'
          }`}>
            {track.source === 'upload' ? (
              <span className="flex items-center gap-1"><HardDrive className="h-2.5 w-2.5" />Local</span>
            ) : (
              <span className="flex items-center gap-1"><Cloud className="h-2.5 w-2.5" />Web</span>
            )}
          </span>
        </div>
      </div>

      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8 text-zinc-400 hover:text-red-400 hover:bg-red-500/10"
          onClick={(e) => { e.stopPropagation(); onDelete(); }}
        >
          <Trash2 className="h-3.5 w-3.5" />
        </Button>
      </div>
    </div>
  );
}

// ==================== PLAYER BAR ====================
function PlayerBar() {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const {
    currentTrack,
    isPlaying,
    setIsPlaying,
    togglePlay,
    volume,
    setVolume,
    progress,
    setProgress,
    duration,
    setDuration,
    tracks,
    setCurrentTrack,
  } = usePlayerStore();

  useEffect(() => {
    if (!audioRef.current) {
      audioRef.current = new Audio();
      audioRef.current.addEventListener('timeupdate', () => {
        if (audioRef.current) {
          setProgress(audioRef.current.currentTime);
        }
      });
      audioRef.current.addEventListener('loadedmetadata', () => {
        if (audioRef.current) {
          setDuration(audioRef.current.duration);
        }
      });
      audioRef.current.addEventListener('ended', () => {
        setIsPlaying(false);
        // Play next track
        const { currentTrack: ct, tracks: ts } = usePlayerStore.getState();
        if (ct) {
          const idx = ts.findIndex((t) => t.id === ct.id);
          if (idx >= 0 && idx < ts.length - 1) {
            const next = ts[idx + 1];
            setCurrentTrack(next);
          }
        }
      });
    }
  }, [setProgress, setDuration, setIsPlaying, setCurrentTrack]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio || !currentTrack) return;

    audio.src = `/api/play/${currentTrack.id}`;
    audio.volume = volume;
    if (isPlaying) {
      audio.play().catch(() => setIsPlaying(false));
    } else {
      audio.pause();
    }
  }, [currentTrack, isPlaying, volume, setIsPlaying]);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume;
    }
  }, [volume]);

  const handleSeek = (value: number[]) => {
    const time = value[0];
    setProgress(time);
    if (audioRef.current) {
      audioRef.current.currentTime = time;
    }
  };

  const playNext = () => {
    if (!currentTrack) return;
    const idx = tracks.findIndex((t) => t.id === currentTrack.id);
    if (idx >= 0 && idx < tracks.length - 1) {
      setCurrentTrack(tracks[idx + 1]);
    }
  };

  const playPrev = () => {
    if (!currentTrack) return;
    const idx = tracks.findIndex((t) => t.id === currentTrack.id);
    if (idx > 0) {
      setCurrentTrack(tracks[idx - 1]);
    } else {
      // Restart current track
      setProgress(0);
      if (audioRef.current) {
        audioRef.current.currentTime = 0;
      }
    }
  };

  if (!currentTrack) {
    return (
      <div className="fixed bottom-0 left-0 right-0 h-20 bg-[#181818] border-t border-zinc-800 flex items-center justify-center px-4 z-40">
        <p className="text-zinc-500 text-sm">No track selected</p>
      </div>
    );
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 h-20 bg-[#181818]/95 backdrop-blur-lg border-t border-zinc-800 flex items-center px-4 z-40">
      {/* Track info */}
      <div className="flex items-center gap-3 w-[30%] min-w-0">
        <div className="w-12 h-12 rounded-md bg-gradient-to-br from-green-600 to-green-900 flex items-center justify-center flex-shrink-0">
          <Music2 className="h-6 w-6 text-white" />
        </div>
        <div className="min-w-0">
          <p className="text-sm font-medium text-white truncate">{currentTrack.title}</p>
          <p className="text-xs text-zinc-400 truncate">{currentTrack.artist || 'Unknown Artist'}</p>
        </div>
      </div>

      {/* Controls */}
      <div className="flex flex-col items-center w-[40%] gap-1">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" className="h-8 w-8 text-zinc-400 hover:text-white" onClick={playPrev}>
            <SkipBack className="h-4 w-4" />
          </Button>
          <Button
            size="icon"
            className="h-9 w-9 rounded-full bg-white text-black hover:scale-105 transition-transform"
            onClick={togglePlay}
          >
            {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4 ml-0.5" />}
          </Button>
          <Button variant="ghost" size="icon" className="h-8 w-8 text-zinc-400 hover:text-white" onClick={playNext}>
            <SkipForward className="h-4 w-4" />
          </Button>
        </div>
        <div className="flex items-center gap-2 w-full max-w-md">
          <span className="text-xs text-zinc-500 w-10 text-right tabular-nums">{formatTime(progress)}</span>
          <div className="flex-1">
            <Slider
              value={[progress]}
              min={0}
              max={duration || 100}
              step={0.1}
              onValueChange={handleSeek}
              className="cursor-pointer"
            />
          </div>
          <span className="text-xs text-zinc-500 w-10 tabular-nums">{formatTime(duration)}</span>
        </div>
      </div>

      {/* Volume */}
      <div className="flex items-center justify-end gap-2 w-[30%]">
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8 text-zinc-400 hover:text-white"
          onClick={() => setVolume(volume === 0 ? 0.7 : 0)}
        >
          {volume === 0 ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
        </Button>
        <div className="w-24 hidden sm:block">
          <Slider
            value={[volume]}
            min={0}
            max={1}
            step={0.01}
            onValueChange={(v) => setVolume(v[0])}
            className="cursor-pointer"
          />
        </div>
      </div>
    </div>
  );
}

// ==================== MAIN APP ====================
export default function MusicPlayer() {
  const {
    tracks,
    setTracks,
    removeTrack,
    currentTrack,
    setCurrentTrack,
    setIsPlaying,
    searchQuery,
    setSearchQuery,
    searchResults,
    setSearchResults,
    isSearching,
    setIsSearching,
  } = usePlayerStore();

  const [uploadOpen, setUploadOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'library' | 'search'>('library');
  const [loading, setLoading] = useState(true);
  const [installPrompt, setInstallPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [canInstall, setCanInstall] = useState(false);

  // Listen for PWA install prompt
  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault();
      setInstallPrompt(e as BeforeInstallPromptEvent);
      setCanInstall(true);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstallApp = async () => {
    if (!installPrompt) return;
    installPrompt.prompt();
    const { outcome } = await installPrompt.userChoice;
    if (outcome === 'accepted') {
      toast.success('App installed!');
    }
    setInstallPrompt(null);
    setCanInstall(false);
  };

  // Load tracks on mount
  useEffect(() => {
    async function loadTracks() {
      try {
        const res = await fetch('/api/tracks');
        if (res.ok) {
          const data = await res.json();
          setTracks(data as Track[]);
        }
      } catch {
        toast.error('Failed to load tracks');
      } finally {
        setLoading(false);
      }
    }
    loadTracks();
  }, [setTracks]);

  const handleSearch = useCallback(async () => {
    if (!searchQuery.trim()) return;
    setIsSearching(true);
    try {
      const res = await fetch('/api/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: searchQuery }),
      });
      if (!res.ok) throw new Error('Search failed');
      const data = await res.json();
      setSearchResults(data as SearchResult[]);
      setActiveTab('search');
    } catch {
      toast.error('Search failed. Try again.');
    } finally {
      setIsSearching(false);
    }
  }, [searchQuery, setIsSearching, setSearchResults]);

  const handlePlay = (track: Track) => {
    if (currentTrack?.id === track.id) {
      usePlayerStore.getState().togglePlay();
    } else {
      setCurrentTrack(track);
      setIsPlaying(true);
    }
  };

  const handleDelete = async (track: Track) => {
    try {
      await fetch(`/api/tracks/${track.id}`, { method: 'DELETE' });
      removeTrack(track.id);
      if (currentTrack?.id === track.id) {
        setCurrentTrack(null);
        setIsPlaying(false);
      }
      toast.success(`"${track.title}" removed`);
    } catch {
      toast.error('Failed to delete');
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#0a0a0a]">
      {/* Header */}
      <header className="sticky top-0 z-30 bg-[#0a0a0a]/80 backdrop-blur-xl border-b border-zinc-800/50">
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center gap-4">
          {/* Logo */}
          <div className="flex items-center gap-2 flex-shrink-0">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-green-500 to-green-700 flex items-center justify-center">
              <Music2 className="h-4 w-4 text-white" />
            </div>
            <span className="text-lg font-bold hidden sm:block">Vibe</span>
          </div>

          {/* Search bar */}
          <div className="flex-1 max-w-xl relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-500" />
            <Input
              placeholder="Search for music..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              className="pl-10 bg-zinc-800/60 border-zinc-700/50 text-white placeholder:text-zinc-500 focus:border-green-500/50 focus:ring-green-500/20"
            />
          </div>

          {/* Install / Upload buttons */}
          <div className="flex items-center gap-2 flex-shrink-0">
            {canInstall && (
              <Button
                onClick={handleInstallApp}
                variant="outline"
                className="border-green-500/50 text-green-400 hover:bg-green-500/10 hover:text-green-300"
              >
                <Smartphone className="h-4 w-4 mr-2" />
                <span className="hidden sm:inline">Install App</span>
              </Button>
            )}
            <Button
              onClick={() => setUploadOpen(true)}
              className="bg-green-600 hover:bg-green-700 text-white font-medium"
            >
              <Upload className="h-4 w-4 mr-2" />
              <span className="hidden sm:inline">Upload</span>
            </Button>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-4 py-6 pb-28">
        {/* Tabs */}
        <div className="flex gap-2 mb-6">
          <Button
            variant={activeTab === 'library' ? 'default' : 'ghost'}
            onClick={() => setActiveTab('library')}
            className={activeTab === 'library'
              ? 'bg-zinc-800 text-white hover:bg-zinc-700'
              : 'text-zinc-400 hover:text-white'
            }
          >
            <ListMusic className="h-4 w-4 mr-2" />
            My Library
            {tracks.length > 0 && (
              <span className="ml-2 text-xs bg-zinc-700 px-1.5 py-0.5 rounded-full">{tracks.length}</span>
            )}
          </Button>
          <Button
            variant={activeTab === 'search' ? 'default' : 'ghost'}
            onClick={() => setActiveTab('search')}
            className={activeTab === 'search'
              ? 'bg-zinc-800 text-white hover:bg-zinc-700'
              : 'text-zinc-400 hover:text-white'
            }
          >
            <Cloud className="h-4 w-4 mr-2" />
            Search Results
            {searchResults.length > 0 && (
              <span className="ml-2 text-xs bg-zinc-700 px-1.5 py-0.5 rounded-full">{searchResults.length}</span>
            )}
          </Button>
        </div>

        {/* Library Tab */}
        {activeTab === 'library' && (
          <div>
            {loading ? (
              <div className="flex flex-col items-center justify-center py-20">
                <Loader2 className="h-8 w-8 animate-spin text-zinc-600 mb-3" />
                <p className="text-zinc-500 text-sm">Loading your library...</p>
              </div>
            ) : tracks.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-20 text-center">
                <div className="w-20 h-20 rounded-full bg-zinc-800 flex items-center justify-center mb-4">
                  <Music2 className="h-10 w-10 text-zinc-600" />
                </div>
                <h3 className="text-lg font-semibold text-zinc-300 mb-2">Your library is empty</h3>
                <p className="text-zinc-500 text-sm max-w-sm mb-6">
                  Upload your own music files or search the web to find songs. Everything plays offline once added.
                </p>
                <div className="flex gap-3">
                  <Button onClick={() => setUploadOpen(true)} className="bg-green-600 hover:bg-green-700 text-white">
                    <Upload className="h-4 w-4 mr-2" />
                    Upload Files
                  </Button>
                  <Button
                    variant="outline"
                    className="border-zinc-700 text-zinc-300 hover:bg-zinc-800"
                    onClick={() => document.querySelector('input[placeholder="Search for music..."]')?.focus()}
                  >
                    <Search className="h-4 w-4 mr-2" />
                    Search Web
                  </Button>
                </div>
              </div>
            ) : (
              <ScrollArea className="h-[calc(100vh-320px)]">
                <div className="space-y-1">
                  {tracks.map((track) => (
                    <TrackRow
                      key={track.id}
                      track={track}
                      isActive={currentTrack?.id === track.id}
                      onPlay={() => handlePlay(track)}
                      onDelete={() => handleDelete(track)}
                    />
                  ))}
                </div>
              </ScrollArea>
            )}
          </div>
        )}

        {/* Search Tab */}
        {activeTab === 'search' && (
          <div>
            {isSearching ? (
              <div className="flex flex-col items-center justify-center py-20">
                <Loader2 className="h-8 w-8 animate-spin text-green-500 mb-3" />
                <p className="text-zinc-400 text-sm">Searching the web...</p>
              </div>
            ) : searchResults.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-20 text-center">
                <div className="w-20 h-20 rounded-full bg-zinc-800 flex items-center justify-center mb-4">
                  <Search className="h-10 w-10 text-zinc-600" />
                </div>
                <h3 className="text-lg font-semibold text-zinc-300 mb-2">Search for music</h3>
                <p className="text-zinc-500 text-sm max-w-sm">
                  Type a song name, artist, or album in the search bar above. We&apos;ll find it on the web and you can download it for offline playback.
                </p>
              </div>
            ) : (
              <div>
                <p className="text-sm text-zinc-500 mb-3">
                  Found {searchResults.length} results for &quot;{searchQuery}&quot;
                </p>
                <p className="text-xs text-zinc-600 mb-4">
                  Click the download button to save a track for offline playback. Only direct audio files can be downloaded.
                </p>
                <ScrollArea className="h-[calc(100vh-380px)]">
                  <div className="space-y-2">
                    {searchResults.map((result, idx) => (
                      <SearchResultCard key={`${result.url}-${idx}`} result={result} />
                    ))}
                  </div>
                </ScrollArea>
              </div>
            )}
          </div>
        )}
      </main>

      {/* Player bar */}
      <PlayerBar />

      {/* Upload dialog */}
      <UploadDialog open={uploadOpen} onClose={() => setUploadOpen(false)} />
    </div>
  );
}
