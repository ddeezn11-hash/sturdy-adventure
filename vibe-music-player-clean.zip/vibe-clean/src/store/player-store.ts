import { create } from 'zustand';

export interface Track {
  id: string;
  title: string;
  artist?: string | null;
  album?: string | null;
  duration?: number | null;
  fileType: string;
  source: string;
  fileName: string;
  fileSize?: number | null;
  artworkUrl?: string | null;
  createdAt: string;
}

interface PlayerState {
  // Track list
  tracks: Track[];
  setTracks: (tracks: Track[]) => void;
  addTrack: (track: Track) => void;
  removeTrack: (id: string) => void;

  // Queue / current
  queue: Track[];
  setQueue: (tracks: Track[]) => void;
  currentTrack: Track | null;
  setCurrentTrack: (track: Track | null) => void;

  // Playback
  isPlaying: boolean;
  setIsPlaying: (playing: boolean) => void;
  togglePlay: () => void;
  volume: number;
  setVolume: (vol: number) => void;
  progress: number;
  setProgress: (p: number) => void;
  duration: number;
  setDuration: (d: number) => void;

  // Search
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  searchResults: SearchResult[];
  setSearchResults: (results: SearchResult[]) => void;
  isSearching: boolean;
  setIsSearching: (s: boolean) => void;

  // Upload
  isUploading: boolean;
  setIsUploading: (u: boolean) => void;
}

export interface SearchResult {
  title: string;
  artist?: string;
  url: string;
  audioUrl?: string;
  source: string;
  snippet: string;
  type: 'direct' | 'scraped' | 'page';
  artworkUrl?: string;
}

export const usePlayerStore = create<PlayerState>((set, get) => ({
  tracks: [],
  setTracks: (tracks) => set({ tracks }),
  addTrack: (track) => set((s) => ({ tracks: [...s.tracks, track] })),
  removeTrack: (id) => set((s) => ({ tracks: s.tracks.filter((t) => t.id !== id) })),

  queue: [],
  setQueue: (tracks) => set({ queue: tracks }),
  currentTrack: null,
  setCurrentTrack: (track) => {
    set({ currentTrack: track });
    if (track) {
      set((s) => ({
        queue: s.tracks.length > 0 ? s.tracks : [track],
      }));
    }
  },

  isPlaying: false,
  setIsPlaying: (playing) => set({ isPlaying: playing }),
  togglePlay: () => set((s) => ({ isPlaying: !s.isPlaying })),
  volume: 0.7,
  setVolume: (vol) => set({ volume: vol }),
  progress: 0,
  setProgress: (p) => set({ progress: p }),
  duration: 0,
  setDuration: (d) => set({ duration: d }),

  searchQuery: '',
  setSearchQuery: (q) => set({ searchQuery: q }),
  searchResults: [],
  setSearchResults: (results) => set({ searchResults: results }),
  isSearching: false,
  setIsSearching: (s) => set({ isSearching: s }),

  isUploading: false,
  setIsUploading: (u) => set({ isUploading: u }),
}));
